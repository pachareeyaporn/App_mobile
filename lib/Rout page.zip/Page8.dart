import 'package:flutter/material.dart';

class Page8 extends StatefulWidget {
  @override
  _Page8State createState() => _Page8State();
}

class _Page8State extends State<Page8> {
  int likeCount = 0;
  int dislikeCount = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ก๋วยเตี๋ยวเรือ"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              "https://cheewajit.com/app/uploads/2021/04/image-130-edited.png",
              width: 300,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 20),
            Text(
              "เมนู: ก๋วยเตี๋ยวเรือ",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              "ส่วนผสม:\n- เครื่องเทศสำหรับน้ำซุป\n- เครื่องปรุงรส\n- เส้นก๋วยเตี๋ยว\n- ต้นหอมและผักชี\n- กระเทียมเจียว\n- ถั่วลิสงบด",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_up, color: Colors.green),
                      onPressed: () {
                        setState(() {
                          likeCount++;
                        });
                      },
                    ),
                    Text('$likeCount'),
                  ],
                ),
                SizedBox(width: 20),
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_down, color: Colors.red),
                      onPressed: () {
                        setState(() {
                          dislikeCount++;
                        });
                      },
                    ),
                    Text('$dislikeCount'),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("กลับไปเมนูหลัก"),
            ),
          ],
        ),
      ),
    );
  }
}
