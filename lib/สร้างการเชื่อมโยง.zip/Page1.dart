import 'package:flutter/material.dart';

class Page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> foodList = [
      {"name": "ต้มยำกุ้ง", "route": "/page2"},
      {"name": "ผัดไทย", "route": "/page3"},
      {"name": "แกงเขียวหวาน", "route": "/page4"},
      {"name": "ส้มตำ", "route": "/page5"},
      {"name": "ข้าวมันไก่", "route": "/page6"},
      {"name": "ข้าวผัด", "route": "/page7"},
      {"name": "ก๋วยเตี๋ยวเรือ", "route": "/page8"},
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text("เมนูอาหาร"),
      ),
      body: ListView.builder(
        itemCount: foodList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(foodList[index]['name']!),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.pushNamed(context, foodList[index]['route']!);
            },
          );
        },
      ),
    );
  }
}
